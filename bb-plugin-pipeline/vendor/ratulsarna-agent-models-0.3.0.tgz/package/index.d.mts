import type { AgentModels } from "./schema.mjs";
export interface AgentModelSettings {
  models: AgentModels;
  revision: string;
  path: string;
  source: "defaults" | "file";
}
export function configPath(): string;
export function readAgentModels(path?: string): AgentModelSettings;
export function writeAgentModels(models: AgentModels, expectedRevision: string, path?: string): Promise<AgentModelSettings>;
