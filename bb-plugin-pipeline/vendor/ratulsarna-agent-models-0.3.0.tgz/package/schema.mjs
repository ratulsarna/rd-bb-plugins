export const DEFAULT_REVIEW_MODELS = Object.freeze({
  first: Object.freeze({ providerId: "codex", model: "gpt-6-sol", reasoningLevel: "high" }),
  second: Object.freeze({ providerId: "pi", model: "zai/glm-5.3-flash", reasoningLevel: "high" }),
});

export const DEFAULT_SUBAGENT_MODELS = Object.freeze({
  oracle: Object.freeze({ providerId: "codex", model: "gpt-6-sol", reasoningLevel: "xhigh" }),
  complex: Object.freeze({ providerId: "codex", model: "gpt-6-sol", reasoningLevel: "high" }),
  workhorse: Object.freeze({ providerId: "pi", model: "zai/glm-5.3-flash", reasoningLevel: "high" }),
  qa: Object.freeze({ providerId: "codex", model: "gpt-6-luna", reasoningLevel: "max" }),
});

function object(value, keys, label) {
  if (!value || typeof value !== "object" || Array.isArray(value) ||
      Object.keys(value).some((key) => !keys.includes(key)) ||
      keys.some((key) => !Object.hasOwn(value, key))) {
    throw new Error(`${label} must contain exactly ${keys.join(", ")}`);
  }
}

function parseSelection(value, label) {
  const fields = ["providerId", "model", "reasoningLevel"];
  if (value && Object.hasOwn(value, "serviceTier")) fields.push("serviceTier");
  object(value, fields, label);
  const { providerId, model, reasoningLevel, serviceTier } = value;
  if (typeof providerId !== "string" || !/^[a-zA-Z0-9][a-zA-Z0-9._/-]{0,127}$/.test(providerId)) {
    throw new Error(`${label} needs a harness ID`);
  }
  if (serviceTier !== undefined && serviceTier !== "default" && serviceTier !== "fast") {
    throw new Error(`${label} has an invalid service tier`);
  }
  if (typeof model !== "string" || !model.trim() || model.length > 256 || /[\s\x00-\x1f]/.test(model)) {
    throw new Error(`${label} needs a model ID without whitespace`);
  }
  if (typeof reasoningLevel !== "string" || !/^[a-z][a-z0-9_-]{0,31}$/.test(reasoningLevel)) {
    throw new Error(`${label} needs a reasoning level`);
  }
  return { providerId, model, reasoningLevel, ...(serviceTier === undefined ? {} : { serviceTier }) };
}

function parseSlots(value, slots, label, noun) {
  object(value, slots, label);
  return Object.fromEntries(slots.map((slot) => [slot, parseSelection(value[slot], `${slot} ${noun}`)]));
}

export function parseReviewModels(value) {
  return parseSlots(value, ["first", "second"], "Review models", "reviewer");
}

export function parseSubagentModels(value) {
  return parseSlots(value, ["oracle", "complex", "workhorse", "qa"], "Subagent models", "subagent");
}

export function parseAgentModels(value) {
  object(value, ["review", "subagents"], "Agent models");
  return { review: parseReviewModels(value.review), subagents: parseSubagentModels(value.subagents) };
}

export function parseConfig(value) {
  if (value?.version === 3) {
    object(value, ["version", "review", "subagents"], "Agent model config");
    return parseAgentModels({ review: value.review, subagents: value.subagents });
  }
  object(value, ["version", "review"], "Agent model config");
  let review = value.review;
  if (value.version === 1) {
    object(review, ["codex", "glm"], "Review models");
    review = {};
    for (const [old, role, providerId] of [["codex", "first", "codex"], ["glm", "second", "pi"]]) {
      object(value.review[old], ["model", "reasoningLevel"], `${old} reviewer`);
      review[role] = { providerId, ...value.review[old] };
    }
  } else if (value.version !== 2) {
    throw new Error("Unsupported agent model config version");
  }
  // Older files predate subagent roles; they use the defaults until the next save.
  return { review: parseReviewModels(review), subagents: structuredClone(DEFAULT_SUBAGENT_MODELS) };
}
