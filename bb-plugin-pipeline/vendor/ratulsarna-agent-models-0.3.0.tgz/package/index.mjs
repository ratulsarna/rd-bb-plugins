import { createHash, randomUUID } from "node:crypto";
import { lstatSync, readFileSync, realpathSync } from "node:fs";
import { mkdir, writeFile, rename, rm } from "node:fs/promises";
import { homedir } from "node:os";
import { dirname, join, resolve } from "node:path";
import { DEFAULT_REVIEW_MODELS, DEFAULT_SUBAGENT_MODELS, parseAgentModels, parseConfig } from "./schema.mjs";

export function configPath() {
  return resolve(process.env.AGENT_MODELS_CONFIG ||
    join(process.env.XDG_CONFIG_HOME || join(homedir(), ".config"), "agent-models", "config.json"));
}

function targetPath(path) {
  try {
    return realpathSync(path);
  } catch (error) {
    if (error.code !== "ENOENT") throw error;
    // A missing synced target must not turn into an unrelated local config.
    try {
      if (lstatSync(path).isSymbolicLink()) throw new Error(`Config symlink has no target: ${path}`);
    } catch (statError) {
      if (statError.code !== "ENOENT") throw statError;
    }
    return path;
  }
}

// Synchronous so BB can build thread instructions from it on the thread-start path.
export function readAgentModels(path = configPath()) {
  const target = targetPath(path);
  let text;
  try {
    text = readFileSync(target, "utf8");
  } catch (error) {
    if (error.code === "ENOENT") return {
      models: structuredClone({ review: DEFAULT_REVIEW_MODELS, subagents: DEFAULT_SUBAGENT_MODELS }),
      revision: "missing", path, source: "defaults",
    };
    throw new Error(`Cannot read agent models at ${path}: ${error.message}`);
  }
  try {
    return {
      models: parseConfig(JSON.parse(text)),
      revision: createHash("sha256").update(text).digest("hex"), path, source: "file",
    };
  } catch (error) {
    throw new Error(`Invalid agent models at ${path}: ${error.message}`);
  }
}

export async function writeAgentModels(models, expectedRevision, path = configPath()) {
  const parsed = parseAgentModels(models);
  if (typeof expectedRevision !== "string" || !expectedRevision) throw new Error("Read agent model settings before saving");
  const target = targetPath(path);
  await mkdir(dirname(target), { recursive: true });
  const lock = `${target}.lock`;
  try {
    await mkdir(lock);
  } catch (error) {
    if (error.code === "EEXIST") throw new Error(`Agent model settings are being saved. Retry, or remove a stale lock at ${lock}`);
    throw error;
  }
  const temporary = join(dirname(target), `.agent-models-${randomUUID()}.tmp`);
  try {
    const current = readAgentModels(path);
    if (current.revision !== expectedRevision) throw new Error("Agent model settings changed. Reload them before saving.");
    await writeFile(temporary, JSON.stringify({ version: 3, ...parsed }, null, 2) + "\n", { flag: "wx", mode: 0o600 });
    // Rename the resolved target so the user's sync symlink stays in place.
    await rename(temporary, target);
    return readAgentModels(path);
  } finally {
    await rm(temporary, { force: true });
    await rm(lock, { recursive: true, force: true });
  }
}
