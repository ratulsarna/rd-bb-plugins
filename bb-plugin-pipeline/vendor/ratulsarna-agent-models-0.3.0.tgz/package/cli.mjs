#!/usr/bin/env node
import { readAgentModels } from "./index.mjs";
try {
  if (process.argv.length !== 2) throw new Error("Usage: agent-models (prints current review and subagent settings as JSON)");
  process.stdout.write(JSON.stringify(readAgentModels(), null, 2) + "\n");
} catch (error) {
  console.error(error.message);
  process.exitCode = 1;
}
