export interface ModelSelection { providerId: string; model: string; reasoningLevel: string; serviceTier?: "default" | "fast" }
export type ReviewModels = { first: ModelSelection; second: ModelSelection; shape: ModelSelection };
export type SubagentModels = { oracle: ModelSelection; complex: ModelSelection; workhorse: ModelSelection; qa: ModelSelection };
export interface AgentModels { review: ReviewModels; subagents: SubagentModels }
export const DEFAULT_REVIEW_MODELS: Readonly<{ [K in keyof ReviewModels]: Readonly<ModelSelection> }>;
export const DEFAULT_SUBAGENT_MODELS: Readonly<{ [K in keyof SubagentModels]: Readonly<ModelSelection> }>;
export function parseReviewModels(value: unknown): ReviewModels;
export function parseSubagentModels(value: unknown): SubagentModels;
export function parseAgentModels(value: unknown): AgentModels;
export function parseConfig(value: unknown): AgentModels;
