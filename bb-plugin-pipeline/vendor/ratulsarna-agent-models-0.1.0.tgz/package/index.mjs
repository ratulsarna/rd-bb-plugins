import { createHash, randomUUID } from "node:crypto";
import { readFile, realpath, lstat, mkdir, writeFile, rename, rm } from "node:fs/promises";
import { homedir } from "node:os";
import { dirname, join, resolve } from "node:path";
import { DEFAULT_REVIEW_MODELS, parseConfig, parseReviewModels } from "./schema.mjs";

export function configPath() {
  return resolve(process.env.AGENT_MODELS_CONFIG ||
    join(process.env.XDG_CONFIG_HOME || join(homedir(), ".config"), "agent-models", "config.json"));
}

async function targetPath(path) {
  try {
    return await realpath(path);
  } catch (error) {
    if (error.code !== "ENOENT") throw error;
    // A missing synced target must not turn into an unrelated local config.
    try {
      if ((await lstat(path)).isSymbolicLink()) throw new Error(`Config symlink has no target: ${path}`);
    } catch (statError) {
      if (statError.code !== "ENOENT") throw statError;
    }
    return path;
  }
}

export async function readReviewModels(path = configPath()) {
  const target = await targetPath(path);
  let text;
  try {
    text = await readFile(target, "utf8");
  } catch (error) {
    if (error.code === "ENOENT") return {
      models: structuredClone(DEFAULT_REVIEW_MODELS), revision: "missing", path,
      source: "defaults",
    };
    throw new Error(`Cannot read review models at ${path}: ${error.message}`);
  }
  try {
    return {
      models: parseConfig(JSON.parse(text)).review,
      revision: createHash("sha256").update(text).digest("hex"), path, source: "file",
    };
  } catch (error) {
    throw new Error(`Invalid review models at ${path}: ${error.message}`);
  }
}

export async function writeReviewModels(models, expectedRevision, path = configPath()) {
  const review = parseReviewModels(models);
  if (typeof expectedRevision !== "string" || !expectedRevision) throw new Error("Read review settings before saving");
  const target = await targetPath(path);
  await mkdir(dirname(target), { recursive: true });
  const lock = `${target}.lock`;
  try {
    await mkdir(lock);
  } catch (error) {
    if (error.code === "EEXIST") throw new Error(`Review settings are being saved. Retry, or remove a stale lock at ${lock}`);
    throw error;
  }
  const temporary = join(dirname(target), `.agent-models-${randomUUID()}.tmp`);
  try {
    const current = await readReviewModels(path);
    if (current.revision !== expectedRevision) throw new Error("Review settings changed. Reload them before saving.");
    await writeFile(temporary, JSON.stringify({ version: 1, review }, null, 2) + "\n", { flag: "wx", mode: 0o600 });
    // Rename the resolved target so the user's sync symlink stays in place.
    await rename(temporary, target);
    return await readReviewModels(path);
  } finally {
    await rm(temporary, { force: true });
    await rm(lock, { recursive: true, force: true });
  }
}
