export interface ReviewModel { model: string; reasoningLevel: string }
export interface ReviewModels { codex: ReviewModel; glm: ReviewModel }
export const DEFAULT_REVIEW_MODELS: Readonly<{ codex: Readonly<ReviewModel>; glm: Readonly<ReviewModel> }>;
export function parseReviewModels(value: unknown): ReviewModels;
export function parseConfig(value: unknown): { version: 1; review: ReviewModels };
