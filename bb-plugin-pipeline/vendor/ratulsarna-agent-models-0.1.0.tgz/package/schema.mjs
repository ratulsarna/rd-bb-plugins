export const DEFAULT_REVIEW_MODELS = Object.freeze({
  codex: Object.freeze({ model: "gpt-6-sol", reasoningLevel: "high" }),
  glm: Object.freeze({ model: "zai/glm-5.3-flash", reasoningLevel: "high" }),
});

function object(value, keys, label) {
  if (!value || typeof value !== "object" || Array.isArray(value) ||
      Object.keys(value).some((key) => !keys.includes(key)) ||
      keys.some((key) => !Object.hasOwn(value, key))) {
    throw new Error(`${label} must contain exactly ${keys.join(", ")}`);
  }
}

export function parseReviewModels(value) {
  object(value, ["codex", "glm"], "Review models");
  const result = {};
  for (const role of ["codex", "glm"]) {
    object(value[role], ["model", "reasoningLevel"], `${role} reviewer`);
    const { model, reasoningLevel } = value[role];
    if (typeof model !== "string" || !model.trim() || model.length > 256 || /[\s\x00-\x1f]/.test(model)) {
      throw new Error(`${role} reviewer needs a model ID without whitespace`);
    }
    if (typeof reasoningLevel !== "string" || !/^[a-z][a-z0-9_-]{0,31}$/.test(reasoningLevel)) {
      throw new Error(`${role} reviewer needs a reasoning level`);
    }
    result[role] = { model, reasoningLevel };
  }
  return result;
}

export function parseConfig(value) {
  object(value, ["version", "review"], "Agent model config");
  if (value.version !== 1) throw new Error("Unsupported agent model config version");
  return { version: 1, review: parseReviewModels(value.review) };
}
