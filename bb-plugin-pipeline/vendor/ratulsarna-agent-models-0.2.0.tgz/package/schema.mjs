export const DEFAULT_REVIEW_MODELS = Object.freeze({
  first: Object.freeze({ providerId: "codex", model: "gpt-6-sol", reasoningLevel: "high" }),
  second: Object.freeze({ providerId: "pi", model: "zai/glm-5.3-flash", reasoningLevel: "high" }),
});

function object(value, keys, label) {
  if (!value || typeof value !== "object" || Array.isArray(value) ||
      Object.keys(value).some((key) => !keys.includes(key)) ||
      keys.some((key) => !Object.hasOwn(value, key))) {
    throw new Error(`${label} must contain exactly ${keys.join(", ")}`);
  }
}

export function parseReviewModels(value) {
  object(value, ["first", "second"], "Review models");
  const result = {};
  for (const role of ["first", "second"]) {
    const fields = ["providerId", "model", "reasoningLevel"];
    if (value[role] && Object.hasOwn(value[role], "serviceTier")) fields.push("serviceTier");
    object(value[role], fields, `${role} reviewer`);
    const { providerId, model, reasoningLevel, serviceTier } = value[role];
    if (typeof providerId !== "string" || !/^[a-zA-Z0-9][a-zA-Z0-9._/-]{0,127}$/.test(providerId)) {
      throw new Error(`${role} reviewer needs a harness ID`);
    }
    if (serviceTier !== undefined && serviceTier !== "default" && serviceTier !== "fast") {
      throw new Error(`${role} reviewer has an invalid service tier`);
    }
    if (typeof model !== "string" || !model.trim() || model.length > 256 || /[\s\x00-\x1f]/.test(model)) {
      throw new Error(`${role} reviewer needs a model ID without whitespace`);
    }
    if (typeof reasoningLevel !== "string" || !/^[a-z][a-z0-9_-]{0,31}$/.test(reasoningLevel)) {
      throw new Error(`${role} reviewer needs a reasoning level`);
    }
    result[role] = { providerId, model, reasoningLevel, ...(serviceTier === undefined ? {} : { serviceTier }) };
  }
  return result;
}

export function parseConfig(value) {
  object(value, ["version", "review"], "Agent model config");
  if (value.version === 1) {
    object(value.review, ["codex", "glm"], "Review models");
    const review = {};
    for (const [old, role, providerId] of [["codex", "first", "codex"], ["glm", "second", "pi"]]) {
      object(value.review[old], ["model", "reasoningLevel"], `${old} reviewer`);
      review[role] = { providerId, ...value.review[old] };
    }
    return { version: 2, review: parseReviewModels(review) };
  }
  if (value.version !== 2) throw new Error("Unsupported agent model config version");
  return { version: 2, review: parseReviewModels(value.review) };
}
