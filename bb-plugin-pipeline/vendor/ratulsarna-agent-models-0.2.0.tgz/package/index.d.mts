import type { ReviewModels } from "./schema.mjs";
export interface ReviewModelSettings {
  models: ReviewModels;
  revision: string;
  path: string;
  source: "defaults" | "file";
}
export function configPath(): string;
export function readReviewModels(path?: string): Promise<ReviewModelSettings>;
export function writeReviewModels(models: ReviewModels, expectedRevision: string, path?: string): Promise<ReviewModelSettings>;
