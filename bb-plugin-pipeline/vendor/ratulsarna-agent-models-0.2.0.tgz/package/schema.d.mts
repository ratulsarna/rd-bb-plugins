export interface ReviewModel { providerId: string; model: string; reasoningLevel: string; serviceTier?: "default" | "fast" }
export interface ReviewModels { first: ReviewModel; second: ReviewModel }
export const DEFAULT_REVIEW_MODELS: Readonly<{ first: Readonly<ReviewModel>; second: Readonly<ReviewModel> }>;
export function parseReviewModels(value: unknown): ReviewModels;
export function parseConfig(value: unknown): { version: 2; review: ReviewModels };
